﻿import numpy as np
import matplotlib.pyplot as plt
import time
#import scipy.optimize as opt


Xdata = np.array([], dtype = float)
Ydata = np.array([], dtype = float)


print("opening and reading...")
xDataFile = open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\xDataFile.txt", 'r')
yDataFile = open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\yDataFile.txt", 'r')


a = xDataFile.read()
print("x file read.")
b = yDataFile.read()
print("y file read.")
ta = np.array(a.split("\n"))
tb = np.array(b.split("\n"))

for i in range(0, len(ta)-1, 1):
    Xdata = np.append(Xdata, ta[i])
    Ydata = np.append(Ydata, tb[i])

n = 0

while(n < ta.size-1):
    print("ta = \""+ ta[n] + "\"\n")
    n = n+1
n = 0
while(n < tb.size-1):
    print("tb = \""+ tb[n] + "\"\n")
    n = n+1

#parsing
for i in range(0, len(ta)-1, 1):
    Xdata = np.append(Xdata, float(ta[i]))
    Ydata = np.append(Ydata, float(tb[i]))

#arrayName = input("Enter array name: ")

# Take information for title of graph, etc, etc


#Kcode.write("double[] "+ arrayName + " = [")
#n = 0
#while(n < t.size):
#    try:
#        print("\""+ t[n] + "\"")
#        Kcode.write(t[n] + ", ")
#    except ValueError:
#        print("couldn't append \"" + t[n] + "\"")
#    n = n+1

xDataFile.close()
yDataFile.close()

plt.plot(Xdata, Ydata)
plt.savefig("C:\\Users\\Ambrose158\\Desktop\\Graphing\\plots.jpg")
plt.show()

print("opening and reading...")
xDataFile = open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\2xDataFile.txt", 'r')
yDataFile = open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\2yDataFile.txt", 'r')


a = xDataFile.read()
print("x file read.")
b = yDataFile.read()
print("y file read.")
ta = np.array(a.split("\n"))
tb = np.array(b.split("\n"))

for i in range(0, len(ta)-1, 1):
    Xdata = np.append(Xdata, ta[i])
    Ydata = np.append(Ydata, tb[i])

n = 0

while(n < ta.size-1):
    print("ta = \""+ ta[n] + "\"\n")
    n = n+1
n = 0
while(n < tb.size-1):
    print("tb = \""+ tb[n] + "\"\n")
    n = n+1

#parsing
for i in range(0, len(ta)-1, 1):
    Xdata = np.append(Xdata, float(ta[i]))
    Ydata = np.append(Ydata, float(tb[i]))

xDataFile.close()
yDataFile.close()

plt.plot(Xdata, Ydata)
plt.savefig("C:\\Users\\Ambrose158\\Desktop\\Graphing\\2ndPlot.jpg")
plt.show()

