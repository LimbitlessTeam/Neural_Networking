// PlotToFile.cpp : Defines the entry point for the console application.
//

// CreateGraph.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"
#include "Solver.h"

using namespace std;
double e = 2.71828;
int nmP = 10;
double * Xdata = new double[nmP + 1];
double * Ydata = new double[nmP + 1];
double VPpure1 = 1;
double VPpure2 = 2;


ofstream xfile;
ofstream yfile;

/*
double Func1(double x)
{
	return partialPress1(x) / (partialPress1(x) + partialPress2(x));
}
double Func2(double y)
{
	return y;
}



double activity1(double x)
{
	return pow(e, .5 * (1 - x)*(1 - x));
}
double activity2(double x)
{
	return pow(e, .5 * x*x);
}
double partialPress1(double x)
{
	return activity1(x) * x * VPpure1;
}
double partialPress2(double x)
{
	return activity2(x) * (1 - x) * VPpure2;
}

*/


int main()
{	
	//Calculate vapor liquid phase diagram for boiling point
		
	for (int i = 0; i < nmP+1; i++)
	{
		// example code of filling up data, this is just a chem E function
		// you may as well consider it x = a count of 0 to 10 
		// and y = F(x)
		//Xdata[i] = double(i) / 10;
		//Ydata[i] = partialPress1(Xdata[i]) + partialPress2(Xdata[i]);
	}

	yfile.open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\yDataFile.txt");
	xfile.open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\xDataFile.txt");

	// load data into text files

	for (int i = 0; i < nmP+1; i++)
	{
		cout << Xdata[i];
		xfile << Xdata[i];
		xfile << "\n";
	}

	for (int i = 0; i < nmP+1; i++)
	{
		yfile << Ydata[i];
		yfile << "\n";
	}
	xfile.close();
	yfile.close();

	// stopping point 1

	cout << "Pausing in order for you to run grapher \n";
	system("pause");

	double tempX;

	// Calculate data for dew point calcs

	for (int i = 0; i < nmP + 1; i++)
	{
		Xdata[i] = double(i) / 10;

		tempX = solver(Xdata[i], Xdata[i]); //Xdata is now y's and guess for x is y
			//kind of confusing sorry
		Ydata[i] = Xdata[i] / activity1(tempX) * VPpure1;
		cout << "\nPress: " << Ydata[i] << ENDL;
		Ydata[i] = Ydata[i] + ((1-Xdata[i]) / (activity2(tempX) * VPpure2));
		cout << "\nPress: " << Ydata[i] << ENDL;
		Ydata[i] = 1 / Ydata[i];

		cout << "\n\nact1: " << activity1(tempX);
		cout << "\n1-y: " << 1 - Xdata[i];
		cout << "\nact2: " << activity2(tempX);
		cout << "\nPress: " << Ydata[i] << ENDL;
		cout << "\n";

		system("pause");

	}

	xfile.open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\2xDataFile.txt");
	yfile.open("C:\\Users\\Ambrose158\\Desktop\\Graphing\\2yDataFile.txt");

	for (int i = 0; i < nmP + 1; i++)
	{
		cout << Xdata[i] << " \n";
		xfile << Xdata[i];
		xfile << "\n";
	}

	for (int i = 0; i < nmP + 1; i++)
	{
		cout << Ydata[i] << " \n";
		yfile << Ydata[i];
		yfile << "\n";
	}
	xfile.close();
	yfile.close();
	system("pause");

	return 0;
}