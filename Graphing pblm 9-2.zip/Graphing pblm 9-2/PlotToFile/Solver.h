#pragma once

#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

#define ENDL "\n";

double Func1(double x);
double Func2(double x);
double activity1(double x);
double activity2(double x);
double partialPress1(double x);
double partialPress2(double x);


double solver(double x, double y)
{
	double delx = .1;
	double diff = abs(Func1(x) - Func2(y));

	while (diff > .00001)
	{

		if ((Func1(x) - Func2(y)) - (Func1(x + delx) - Func2(y)) < 0)
		{
			delx = -1 * diff / 10;
		}
		else {
			delx = 1 * diff / 10;
		}

		x = x + delx;
		//cout << "x: " << x << endl;
		cout << "func1(x): " << Func1(x) << endl;
		cout << "Func2(y): " << Func2(y) << endl;
		//cout << "diff: " << abs(Func1(x) - Func2(y)) << endl;
		//cout << "delx: " << delx << endl;
		//system("pause");

		diff = abs(Func1(x) - Func2(y));
		if (diff < .001)
		{
			cout << endl << endl << "DIFFERENCE NOW .001: " << diff << endl;
		}
		if (diff < .0001)
		{
			cout << endl << endl << "DIFFERENCE NOW .0001: " << diff << "   ***********" << endl;
		}

	}

	cout << "x: " << x << endl;
	cout << "func1(x): " << Func1(x) << endl;
	cout << "Func2(y): " << Func2(y) << endl;

	//system("pause");


	return x;

}